# -*- coding: UTF-8 -*-
__author__ = 'alexkan'

import unittest
from wetest.image_engine import *

class ImageEngineTester(unittest.TestCase):
    def setUp(self):
        pass

    def test_analyze(self):
        pass